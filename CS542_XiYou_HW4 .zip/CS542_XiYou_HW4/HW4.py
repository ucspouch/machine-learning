import numpy as np
import struct
import matplotlib.pyplot as plt
import random

def load_image(filename):
    with open(filename,'rb')as f:
        buf = f.read()
 
    offset = 0
    magic, imageNum, rows, cols = struct.unpack_from('>IIII', buf, offset)
    offset += struct.calcsize('>IIII')
    images = np.empty((imageNum, rows, cols))
    image_size = rows * cols
    fmt = '>'+str(image_size)+'B'
    
    for i in range(imageNum):
        images[i] = np.array(struct.unpack_from(fmt, buf, offset)).reshape((rows,cols))
        offset += struct.calcsize(fmt)
    
    return images

def load_label(filename):
    with open(filename,'rb')as f:
        buf = f.read()

    offset = 0
    magic, LabelNum = struct.unpack_from('>II', buf, offset)
    offset += struct.calcsize('>II')
    Labels = np.zeros((LabelNum))
    
    for i in range(LabelNum):
        Labels[i] = np.array(struct.unpack_from('>B', buf, offset))
        offset += struct.calcsize('>B')
        
    return Labels

train_img = load_image('train-images-idx3-ubyte')
train_img = np.array(train_img)
train_label = load_label('train-labels-idx1-ubyte')
train_label = np.array(train_label)

test_img = load_image('t10k-images-idx3-ubyte')
test_img = np.array(test_img)
test_label = load_label('t10k-labels-idx1-ubyte')
test_label = np.array(test_label)

def Kernel(data,sigma):
    m = data.shape[0]
    k = [[0 for i in range(m)] for j in range(m)]
    
    for i in range(m):
        Xi = data[i]
        for j in range(m):
            Xj = data[j]
            rs =(Xi - Xj).dot(Xi - Xj)
            rs = np.exp(rs / (-2 * sigma ** 2))
            
            k[i][j] = rs
            k[j][i] = rs
    
    return k   
def cal_gxi(svm,i):
    gxi = 0 
    alpha = np.array(svm.alpha)
    Y = np.array(svm.label)
    K = np.array(svm.K[:][i])
    gxi += np.sum(alpha * Y * K)
    gxi += svm.b
    
    return gxi
def cal_Ei(svm,i):
    gxi = cal_gxi(svm,i)
#    print(i,'   gxi,yi',gxi ,svm.label[i])
    return gxi - svm.label[i]
       
def KKT(svm,i):
    gxi = cal_gxi(svm,i)
    yi = svm.label[i]
    h = yi * gxi
    C = svm.C
    ai = svm.alpha[i]
    toler = svm.tolerance
    if(abs(ai) < toler) and (h >= 1):
        return True
    if(abs(ai - C)< toler) and (h <= 1):
        return True
    if(ai > -1 * toler) and (ai < (C + toler)) and (abs(h-1) < toler):
        return True
    
    return False

def selectAlpha_J(svm,E1,i):
    E2 = 0 
    maxdelta = -1
    maxindex = -1
    flag = False
    for j in range(0,svm.num):
        if(j == i):
            flag = False
            continue
        elif(svm.E[j] == 0 or 1 or -1):
            flag = False
            continue
        else:
            
            tmp = cal_Ei(svm,i)
            delta = abs(E1 - tmp) *10
            if(delta > maxdelta):
                E2 = tmp
                maxindex =j
                flag = True
            
    if flag == False:

        ll = list(range(0,svm.num))
        random.shuffle(ll)
        while 1:
            if(ll[0] != i):
                maxindex = ll[0]
                break
            else:
                random.shuffle(ll)   

        E2 = cal_Ei(svm,maxindex)
        
    svm.E[i]=E1
    svm.E[j]=E2       
    return E2,maxindex

def SMO(svm,i):
#    print('E1')
    E1 = cal_Ei(svm,i)
    svm.E[i] = E1
    y1 = svm.label[i]
    T = svm.tolerance 
    if(KKT(svm,i) == False):
#    if((y1*E1<-T) and (svm.alpha[i]<svm.C))or((y1*E1>T) and (svm.alpha[i]>0)):

        E2, j = selectAlpha_J(svm,E1,i)
#        print('select_J:',i,j)
        y2 = svm.label[j]
        svm.E[j] = E2
        a_old_1 = svm.alpha[i]
        a_old_2 = svm.alpha[j]
        k11 = svm.K[i][i]
        k22 = svm.K[j][j]
        k12 = svm.K[i][j]
        k21 = svm.K[j][i]
        
        if y1 != y2:
            L = max(0, a_old_2 - a_old_1)
            H = min(svm.C, a_old_2 - a_old_1 + svm.C)
        else:
            L = max(0, a_old_2 + a_old_1 - svm.C)
            H = min(svm.C, a_old_2 + a_old_1 )
        
        if L == H: return 0
        '''
        update a2,a1
        '''
        eta = k11 + k22 - 2 * k12
        if(eta <= 0): return 0
        a_new_2 = a_old_2 + y2 * (E1 - E2) / eta
        if a_new_2 < L:
            a_new_2 = L
        if a_new_2 > H:
            a_new_2 = H
        
        a_new_1 = a_old_1 + y1 * y2 * (a_old_2 - a_new_2)
        
        if abs(a_new_2 - a_old_2) < 10 ** (-5):return 0
        '''
        update b
        '''
        b1 = svm.b - E1 - y1 * k11 * (a_new_1 - a_old_1) - y2 * k21 * (a_new_2 - a_old_2)
        b2 = svm.b - E2 - y1 * k12 * (a_new_1 - a_old_1) - y2 * k22 * (a_new_2 - a_old_2)
        if a_new_1 > 0 and a_new_1 < svm.C:
            svm.b = b1
        elif a_new_2 >0 and a_new_2 <svm.C:
            svm.b = b2
        else:
            svm.b = (b1 + b2)/2.0  
        '''
        update alpha,E
        '''
        svm.alpha[i] = a_new_1
        svm.alpha[j] = a_new_2

        return 1
    else:
        return 0
             
def train(svm,maxit = 1000):
    m = svm.num
    alpha = svm.alpha
    it = 0
    alpha_change =1
    
    while (it < maxit) and (alpha_change > 0):
        alpha_change = 0
        for i in range(m):
            alpha_change += SMO(svm, i)
        it +=1
           
#    print('alpha_change=',alpha_change)           
    for i in range(len(svm.alpha)):
        if svm.alpha[i] > 0:
            svm.supportvector.append(i)
        
    return svm
   
def calKernel(x1, x2, sigma):
    res = np.sum((x1 - x2)*(x1 - x2))
    res = np.exp(res /(-2 * sigma ** 2))
    
    return res
            
def predict(svm, target):
    res = 0
    for i in svm.supportvector:
        k = calKernel(svm.data[i],target,svm.sigma)
        res += svm.alpha[i] * svm.label[i] * k
    
    res += svm.b
#    print('dis =',res)
    
    return res
  
class SVMStruct:
    def __init__(self,data,label,sigma = 5000,C = 200,tolerance = 0.001):
        self.data = data
        self.label = label
        self.sigma = sigma
        self.C = C
        self.tolerance = tolerance
        self.K = Kernel(self.data, self.sigma)
        self.b = 0
        self.num = self.data.shape[0]
        self.alpha = [0 for i in range(self.num)]
        self.E =np.zeros(self.num)
        self.supportvector =[]

def sample(data,label,t1,t2,n,flag=False):
    if(flag == False):
        slab1 = [i for i, l in enumerate(label) if l == t1]
        slab2 = [i for i, l in enumerate(label) if l == t2]
    else:
        slab1 = [i for i, l in enumerate(label) if l == t1]
        slab2 = [i for i, l in enumerate(label) if l != t1]
        
    random.shuffle(slab1)
    random.shuffle(slab2)

    slab1 = slab1[:n]
    slab2 = slab2[:n]
    
    for ii in slab2:
        slab1.append(ii)
        
    slab = label[slab1]
        
    sdata = []
    for ii in slab1:
        sdata.append(data[ii].flatten())
    sdata = np.array(sdata)
    
    return sdata, slab
      
def check(t1,t2,target,tlabel,num=4,maxit=1000,method = False):
    if(method == False):
        sdata,slab1 = sample(train_img, train_label, t1, t2, num)
        
    else:
        sdata,slab1 = sample(train_img, train_label, t1, t2, num,True)
        
    slab =[]
    for ii in range(len(slab1)):
        if(slab1[ii] == t1):
            slab.append(1)
        else:
            slab.append(-1)
        
    
    svm = SVMStruct(sdata,slab,3000,20,0.0001) 

    model = train(svm,maxit)

    pre = predict(model,target)

    if(pre >= 0 ):

        return t1
    else:

        return t2

#print('i','j')
def DAG(i,j,target,tlabel):
#    print('\n----------------',i,j)
    rs = check(i,j,target,tlabel)

    if(j == 1):
        if(rs == i):
            return i
        else:
            return j
    if(rs != i):
        tmp = DAG(j,j-1,target,tlabel)
        return tmp
    else:
        tmp = DAG(i,j-1,target,tlabel)
        return tmp

def test(num):
    T = [i for i, l in enumerate(test_label)]
    random.shuffle(T)
    T = T[:num]
    t_lab = test_label[T]
    t_img = []
    for i in T:
        t_img.append(test_img[i].flatten())
    print(t_lab)
    print(np.unique(t_lab))
    print('=============')
    correct =0
    for t in range(len(T)):
        pre = DAG(0,9,t_img[t],t_lab[t])
#        print('target label=',t_lab[t],' predict label =',pre)
        if(t_lab[t] == pre):
#            print('good prediction:',t_lab[t],pre)
            correct += 1
    
    accuracy = correct / num *100
    print('\n DAG accuracy=',accuracy,'%')
    '''
    1 vs 1
    '''
    p_label = []
    for t in range(len(T)):
        result =[]
        for i in range(0,9):
            for j in range(i+1,10):
                rs = check(i,j,t_img[t],t_lab[t])
                result.append(rs)
        ll = np.unique(result)
        lo = np.zeros(len(ll))
        
        for i in range(len(result)):
            for j in range(len(ll)):
                if(result[i] == ll[j]):
                    lo[j] += 1
        
        m = max(lo)
        tmp = -1
        
        for i in range(len(lo)):
            if(lo[i] == m):
                tmp = i
        p_label.append(ll[tmp])
#    print(p_label)
    correct = 0
    for i in range(len(p_label)):
        if(p_label[i] == t_lab[i]):
            correct +=1
    print('1vs1 accuracy=',correct/num*100,'%')
    
#    '''
#    1 vs rest
#    '''
#    p_lab=[]
#    for i in range(len(T)):
#        result = []
#        for j in range(0,10):
#            rs = check(j,-100,t_img[t],t_lab[t],True)
#            result.append(rs)
#        
#        max_p=0
#        for k in result:
#            if k > -1:
#                max_p = k
#        p_lab.append(max_p)
#    
#    print(p_lab)
#    correct =0
#    for i in range(len(p_lab)):
#        if(p_lab[i] == t_lab[i]):
#            correct +=1
#    print('1 vs rest accuracy=',correct/num*100,'%')
#    
            
        
        
test(10)

  



